import{s}from"./DOjZPVHf.js";const t=s(null);function f(a,o){t.value&&t.value.toast(a,o)}export{t as a,f as t};
