const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./CileezJ_.js","./DOjZPVHf.js","./entry.BHd8kYAd.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./DOjZPVHf.js";const o=r("App",{web:()=>p(()=>import("./CileezJ_.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
