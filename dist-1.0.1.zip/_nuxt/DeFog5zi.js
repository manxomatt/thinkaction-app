import{l as s}from"./8BWmL_v6.js";const t=s(null);function f(a,o){t.value&&t.value.toast(a,o)}export{t as a,f as t};
